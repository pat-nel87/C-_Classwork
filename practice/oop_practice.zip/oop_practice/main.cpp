#include <iostream>
#include <string>
#include "helloWorld.h"

using namespace std;

int main() 
{
	helloWorld hey;
	hey.heyThere();


	return 0;	
}
