#include <iostream>
#include <string>

using namespace std;

class helloWorld
{
	public:
		void heyThere();
		helloWorld()
		{
						
		}



};

void helloWorld::heyThere() 
{
	cout << "Hey There!"<< endl;
}
